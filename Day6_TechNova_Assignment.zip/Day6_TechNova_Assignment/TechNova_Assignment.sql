
CREATE DATABASE TechNovaDB;
USE TechNovaDB;
create table Department (
Dept_ID int primary key ,
Dept_Name varchar (50) not null unique,
Location varchar(50)
);
CREATE TABLE Employee (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(50) NOT NULL,
    Gender CHAR(1),
    DOB DATE,
    HireDate DATE,
    Dept_ID INT,
    FOREIGN KEY (Dept_ID) REFERENCES Department(Dept_ID)
);
CREATE TABLE Project (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(100) NOT NULL,
    Dept_ID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (Dept_ID) REFERENCES Department(Dept_ID)
);
CREATE TABLE Performance (
    EmpID INT,
    ProjectID INT,
    Rating DECIMAL(3,1),
    ReviewDate DATE,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);
CREATE TABLE Reward (
    EmpID INT,
    RewardMonth VARCHAR(20),
    RewardAmount DECIMAL(10,2),
    PRIMARY KEY (EmpID, RewardMonth),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);
CREATE INDEX idx_empname ON Employee(EmpName);
CREATE INDEX idx_deptid ON Employee(Dept_ID);
INSERT INTO Department (Dept_ID, Dept_Name, Location) VALUES
(01, 'IT', 'Kochi'),
(02, 'HR', 'Delhi'),
(03, 'Full stack', 'Mumbai'),
(04, 'Salesforce', 'Chennai'),
(05, 'Support', 'Pune');
INSERT INTO Employee (EmpID, EmpName, Gender, DOB, HireDate, Dept_ID) VALUES
(1, 'Amirva', 'F', '2003-09-23', '2020-03-15', 01),
(2, 'Rajan', 'M', '2004-03-11', '2019-07-10', 02),
(3, 'Cheenu', 'M', '1998-09-20', '2021-01-05', 03),
(4, 'Abinaya', 'F', '1999-12-01', '2018-11-12', 04),
(5, 'Anu', 'F', '2003-12-24', '2022-03-21', 01);
INSERT INTO Project (ProjectID, ProjectName, Dept_ID, StartDate, EndDate) VALUES
(201, 'ERP System', 01, '2020-01-10', '2020-12-30'),
(202, 'HR Portal', 02, '2021-03-01', '2021-10-30'),
(203, 'Finance Tracker', 03, '2022-06-15', '2023-02-20'),
(204, 'Ad Campaign', 04, '2021-08-05', '2022-01-25'),
(205, 'Customer Support Tool', 05, '2022-09-10', '2023-05-15');
INSERT INTO Performance (EmpID, ProjectID, Rating, ReviewDate) VALUES
(1, 201, 4.5, '2023-03-01'),
(2, 202, 4.0, '2023-02-01'),
(3, 203, 4.8, '2023-04-01'),
(4, 204, 3.9, '2023-03-15'),
(5, 205, 4.2, '2023-03-10');
INSERT INTO Reward (EmpID, RewardMonth, RewardAmount) VALUES
(1, 'January', 2500),
(2, 'February', 1800),
(3, 'March', 2700),
(4, 'April', 950),
(5, 'May', 3000);

UPDATE Employee
SET Dept_ID = 01
WHERE EmpName = 'Rajan';
USE Employee_Management;

SELECT * FROM Employee WHERE HireDate > '2019-01-01';

SELECT d.Dept_Name, ROUND(AVG(p.Rating),2) AS Avg_Rating
FROM Employee e
JOIN Performance p ON e.EmpID = p.EmpID
JOIN Department d ON e.Dept_ID = d.Dept_ID
GROUP BY d.Dept_Name;

SELECT EmpName, DOB, TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;

SELECT SUM(RewardAmount) AS Total_Rewards FROM Reward;

SELECT e.EmpName, r.RewardAmount
FROM Employee e
JOIN Reward r ON e.EmpID = r.EmpID
WHERE r.RewardAmount > 2000;

SELECT e.EmpName, d.Dept_Name, pr.Rating, p.ProjectName
FROM Employee e
JOIN Department d ON e.Dept_ID = d.Dept_ID
JOIN Performance pr ON e.EmpID = pr.EmpID
JOIN Project p ON pr.ProjectID = p.ProjectID;

SELECT d.Dept_Name, e.EmpName, p.Rating
FROM Employee e
JOIN Department d ON e.Dept_ID = d.Dept_ID
JOIN Performance p ON e.EmpID = p.EmpID
WHERE (d.Dept_ID, p.Rating) IN (
  SELECT e2.Dept_ID, MAX(p2.Rating)
  FROM Employee e2
  JOIN Performance p2 ON e2.EmpID = p2.EmpID
  GROUP BY e2.Dept_ID
);

SELECT EmpName FROM Employee
WHERE EmpID NOT IN (SELECT EmpID FROM Reward);

-- Transaction 
START TRANSACTION;

INSERT INTO Employee (EmpID, EmpName, Gender, DOB, HireDate, Dept_ID)
VALUES (6, 'Kavin', 'M', '1999-10-10', '2023-09-01', 01);

INSERT INTO Performance (EmpID, ProjectID, Rating, ReviewDate)
VALUES (6, 201, 4.4, '2023-09-20');

COMMIT;

START TRANSACTION;

INSERT INTO Employee (EmpID, EmpName, Gender, DOB, HireDate, Dept_ID)
VALUES (7, 'InvalidEmp', 'M', '2000-11-11', '2024-01-01', 99); -- Dept_ID 99 doesn't exist

--  fail due to foreign key constraint
ROLLBACK;











