Title: Employee Rewards & Performance Management System
Name: Amirtha Varshini S
Database: TechNovaDB
Tool: MySQL Workbench
Assignment: Day 6 MySQL Practice Coding Assignment
Training: Wipro MERN Developer Program

Description:
This project is a complete SQL assignment implementing an Employee Rewards 
and Performance Management System. It includes:

� Database creation (DDL)
� Data insertion, update, delete (DML)
� Data queries with aggregates and date functions (DQL)
� Joins and Subqueries for performance analysis
� Transactions with Commit/Rollback for consistency
� Indexing for query optimization

Files Included:
1. TechNova_Assignment.sql � Full SQL script with all commands.
2. README.txt � Project information and description.

How to Run:
1. Open MySQL Workbench.
2. Copy or open TechNova_Assignment.sql.
3. Run the script step-by-step.
4. The database 'TechNovaDB' will be created and populated automatically.

Author: Amirtha Varshini S
Date: 30/10/2025
